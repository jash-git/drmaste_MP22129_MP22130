﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace first
{
    class Program
    {
        static void Main(string[] args)
        {
            /*  說明：第一個Visual C# 的練習程式 
                日期：2021/12/25  設計人：Jack */
            Console.WriteLine("我的第一個C#程式");
            Console.Read();  //程式暫停等候按鍵
        }
    }
}
