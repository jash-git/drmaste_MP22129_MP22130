﻿namespace Rand
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnEnd = new System.Windows.Forms.Button();
            this.BtnCls = new System.Windows.Forms.Button();
            this.BtnSort = new System.Windows.Forms.Button();
            this.BtnStart = new System.Windows.Forms.Button();
            this.Lbl5 = new System.Windows.Forms.Label();
            this.Lbl4 = new System.Windows.Forms.Label();
            this.Lbl3 = new System.Windows.Forms.Label();
            this.Lbl2 = new System.Windows.Forms.Label();
            this.Lbl1 = new System.Windows.Forms.Label();
            this.Lbl0 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnEnd
            // 
            this.BtnEnd.Location = new System.Drawing.Point(267, 86);
            this.BtnEnd.Name = "BtnEnd";
            this.BtnEnd.Size = new System.Drawing.Size(72, 28);
            this.BtnEnd.TabIndex = 49;
            this.BtnEnd.Text = "結束";
            this.BtnEnd.UseVisualStyleBackColor = true;
            this.BtnEnd.Click += new System.EventHandler(this.BtnEnd_Click);
            // 
            // BtnCls
            // 
            this.BtnCls.Location = new System.Drawing.Point(181, 86);
            this.BtnCls.Name = "BtnCls";
            this.BtnCls.Size = new System.Drawing.Size(72, 28);
            this.BtnCls.TabIndex = 48;
            this.BtnCls.Text = "清除重選";
            this.BtnCls.UseVisualStyleBackColor = true;
            this.BtnCls.Click += new System.EventHandler(this.BtnCls_Click);
            // 
            // BtnSort
            // 
            this.BtnSort.Location = new System.Drawing.Point(95, 86);
            this.BtnSort.Name = "BtnSort";
            this.BtnSort.Size = new System.Drawing.Size(72, 28);
            this.BtnSort.TabIndex = 47;
            this.BtnSort.Text = "依序排列";
            this.BtnSort.UseVisualStyleBackColor = true;
            this.BtnSort.Click += new System.EventHandler(this.BtnSort_Click);
            // 
            // BtnStart
            // 
            this.BtnStart.Location = new System.Drawing.Point(9, 86);
            this.BtnStart.Name = "BtnStart";
            this.BtnStart.Size = new System.Drawing.Size(72, 28);
            this.BtnStart.TabIndex = 46;
            this.BtnStart.Text = "亂數選號";
            this.BtnStart.UseVisualStyleBackColor = true;
            this.BtnStart.Click += new System.EventHandler(this.BtnStart_Click);
            // 
            // Lbl5
            // 
            this.Lbl5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Lbl5.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Lbl5.Location = new System.Drawing.Point(289, 15);
            this.Lbl5.Name = "Lbl5";
            this.Lbl5.Size = new System.Drawing.Size(50, 50);
            this.Lbl5.TabIndex = 45;
            this.Lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl4
            // 
            this.Lbl4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Lbl4.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Lbl4.Location = new System.Drawing.Point(233, 15);
            this.Lbl4.Name = "Lbl4";
            this.Lbl4.Size = new System.Drawing.Size(50, 50);
            this.Lbl4.TabIndex = 44;
            this.Lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl3
            // 
            this.Lbl3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Lbl3.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Lbl3.Location = new System.Drawing.Point(177, 15);
            this.Lbl3.Name = "Lbl3";
            this.Lbl3.Size = new System.Drawing.Size(50, 50);
            this.Lbl3.TabIndex = 43;
            this.Lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl2
            // 
            this.Lbl2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Lbl2.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Lbl2.Location = new System.Drawing.Point(121, 15);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(50, 50);
            this.Lbl2.TabIndex = 42;
            this.Lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl1
            // 
            this.Lbl1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Lbl1.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Lbl1.Location = new System.Drawing.Point(65, 15);
            this.Lbl1.Name = "Lbl1";
            this.Lbl1.Size = new System.Drawing.Size(50, 50);
            this.Lbl1.TabIndex = 41;
            this.Lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Lbl0
            // 
            this.Lbl0.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Lbl0.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Lbl0.Location = new System.Drawing.Point(9, 15);
            this.Lbl0.Name = "Lbl0";
            this.Lbl0.Size = new System.Drawing.Size(50, 50);
            this.Lbl0.TabIndex = 40;
            this.Lbl0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 122);
            this.Controls.Add(this.BtnEnd);
            this.Controls.Add(this.BtnCls);
            this.Controls.Add(this.BtnSort);
            this.Controls.Add(this.BtnStart);
            this.Controls.Add(this.Lbl5);
            this.Controls.Add(this.Lbl4);
            this.Controls.Add(this.Lbl3);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.Lbl1);
            this.Controls.Add(this.Lbl0);
            this.Name = "Form1";
            this.Text = "亂數選號";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnEnd;
        private System.Windows.Forms.Button BtnCls;
        private System.Windows.Forms.Button BtnSort;
        private System.Windows.Forms.Button BtnStart;
        private System.Windows.Forms.Label Lbl5;
        private System.Windows.Forms.Label Lbl4;
        private System.Windows.Forms.Label Lbl3;
        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.Label Lbl1;
        private System.Windows.Forms.Label Lbl0;
    }
}

