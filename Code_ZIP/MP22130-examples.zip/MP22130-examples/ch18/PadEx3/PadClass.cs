﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PadEx3
{
    class PadClass
    {
        private int price;
        public void setPrice(int tPrice)
        { price = tPrice; }
        public int getPrice()
        { return price; }
    }
}
