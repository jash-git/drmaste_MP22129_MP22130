﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConPad
{
    class Program
    {
         class PadClass   // 定義PadClass類別
         {
             public int price;
         }

        static void Main(string[] args)
        {
        }
    }
}
