﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Interface1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            double lb = float.Parse(TxtWT.Text);
            CWeight weight = new CWeight();    //IConvert weight = new CWeight();
            double g = weight.Convert(lb);
            LblMsg.Text = $"{lb} 磅 = {g.ToString("#.##")} 公克";
        }
    }
}
